import './App.css';
import MorphView from './pages/MorphView';

function App() {
  return (
    <div className="App">
      <MorphView />
    </div>
  );
}

export default App;
